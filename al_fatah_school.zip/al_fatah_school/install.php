<?php
require_once __DIR__.'/config/app.php';
$message=''; $error='';
try {
  $stmt=$pdo->prepare("SELECT id FROM users WHERE username='admin' LIMIT 1");$stmt->execute();
  if(!$stmt->fetch()){
    $hash=password_hash('Admin@123',PASSWORD_DEFAULT);
    $ins=$pdo->prepare("INSERT INTO users(full_name,username,email,password,role,status) VALUES(?,?,?,?, 'admin','active')");
    $ins->execute(['School Administrator','admin','admin@alfatah.local',$hash]);
  } else {
    // Leave an existing administrator password unchanged.
  }
  $message='Installation check completed. Default administrator username: admin. Default password: Admin@123 (only if this installer created the account).';
} catch(Throwable $e){$error='Could not complete setup. Import database/al_fatah_school.sql first. Details: '.$e->getMessage();}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Setup | Al-Fatah</title><link rel="stylesheet" href="assets/style.css"></head><body class="login-page"><div class="login-card"><h1>Al-Fatah setup</h1><?php if($message): ?><div class="alert success"><?= htmlspecialchars($message) ?></div><a class="btn primary full" href="login.php">Go to login</a><?php else: ?><div class="alert error"><?= htmlspecialchars($error) ?></div><?php endif; ?><p class="muted" style="margin-top:18px">For security, delete install.php after setup.</p></div></body></html>
