<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
date_default_timezone_set('Africa/Nairobi');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../includes/functions.php';

