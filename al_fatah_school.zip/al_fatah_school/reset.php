<?php
declare(strict_types=1);

// Temporary local-only password reset utility for the Al-Fatah School system.
// Delete this file immediately after resetting the administrator password.

$remoteAddress = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($remoteAddress, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    exit('Access denied. This reset page can only be opened from the local computer.');
}

session_start();
require_once __DIR__ . '/config/database.php';

if (empty($_SESSION['reset_csrf'])) {
    $_SESSION['reset_csrf'] = bin2hex(random_bytes(32));
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string)($_POST['csrf'] ?? '');
    $password = (string)($_POST['new_password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if (!hash_equals($_SESSION['reset_csrf'], $csrf)) {
        $error = 'Invalid request. Refresh the page and try again.';
    } elseif (strlen($password) < 10) {
        $error = 'Choose a password with at least 10 characters.';
    } elseif ($password !== $confirm) {
        $error = 'The passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password = ?, status = 'active' WHERE username = 'admin' AND role = 'admin'");
        $stmt->execute([$hash]);

        if ($stmt->rowCount() > 0) {
            $message = 'Administrator password reset successfully. You can now sign in with username admin and your new password. Delete reset.php immediately.';
        } else {
            $check = $pdo->prepare("SELECT id FROM users WHERE username = 'admin' AND role = 'admin' LIMIT 1");
            $check->execute();
            if ($check->fetch()) {
                $message = 'The administrator account is already using that password or was updated without a detected change. Try signing in, then delete reset.php.';
            } else {
                $error = 'No admin account was found. Run install.php first, then reopen this page.';
            }
        }
        $_SESSION['reset_csrf'] = bin2hex(random_bytes(32));
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Administrator Password | Al-Fatah School</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:20px;background:#f1f5f9;font-family:Arial,sans-serif;color:#172554}.panel{width:100%;max-width:430px;background:#fff;padding:30px;border-radius:14px;box-shadow:0 12px 35px rgba(15,23,42,.1)}h1{font-size:23px;margin:0 0 8px}p{color:#64748b;line-height:1.5;font-size:14px}label{display:block;font-weight:600;margin:17px 0 7px}input{width:100%;padding:12px;border:1px solid #cbd5e1;border-radius:8px;font-size:15px}button{width:100%;margin-top:22px;padding:13px;border:0;border-radius:8px;background:#1d4ed8;color:#fff;font-weight:700;font-size:15px;cursor:pointer}.notice{padding:12px;border-radius:8px;margin:15px 0;font-size:14px;line-height:1.5}.success{background:#dcfce7;color:#166534}.error{background:#fee2e2;color:#991b1b}.warning{background:#fff7ed;color:#9a3412}
</style>
</head>
<body>
<main class="panel">
<h1>Administrator Password Reset</h1>
<p>Al-Fatah Secondary School Management System</p>
<div class="notice warning"><strong>Security:</strong> Use this page only on your local XAMPP computer. Delete <code>reset.php</code> immediately after resetting the password.</div>
<?php if ($message !== ''): ?><div class="notice success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($error !== ''): ?><div class="notice error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<form method="post" autocomplete="off">
<input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['reset_csrf'], ENT_QUOTES, 'UTF-8') ?>">
<label for="new_password">New password</label>
<input id="new_password" type="password" name="new_password" minlength="10" required>
<label for="confirm_password">Confirm new password</label>
<input id="confirm_password" type="password" name="confirm_password" minlength="10" required>
<button type="submit">Reset Admin Password</button>
</form>
</main>
</body>
</html>
