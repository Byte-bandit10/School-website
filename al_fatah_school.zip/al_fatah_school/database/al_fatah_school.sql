CREATE DATABASE IF NOT EXISTS al_fatah_school CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE al_fatah_school;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS results;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS fees;
DROP TABLE IF EXISTS timetable;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS classes;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS examinations;
DROP TABLE IF EXISTS teachers;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 username VARCHAR(80) NOT NULL UNIQUE,
 email VARCHAR(150) NULL,
 password VARCHAR(255) NOT NULL,
 role ENUM('admin','teacher','student','parent') NOT NULL DEFAULT 'admin',
 status ENUM('active','inactive') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE teachers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 teacher_number VARCHAR(40) UNIQUE,
 full_name VARCHAR(150) NOT NULL,
 gender ENUM('Male','Female') NOT NULL,
 phone VARCHAR(30),
 email VARCHAR(150),
 qualification VARCHAR(150),
 employment_date DATE,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE classes (
 id INT AUTO_INCREMENT PRIMARY KEY,
 class_name VARCHAR(30) NOT NULL,
 stream VARCHAR(50) NOT NULL,
 class_teacher_id INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY unique_class_stream(class_name,stream),
 CONSTRAINT fk_class_teacher FOREIGN KEY(class_teacher_id) REFERENCES teachers(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE subjects (
 id INT AUTO_INCREMENT PRIMARY KEY,
 subject_name VARCHAR(100) NOT NULL,
 subject_code VARCHAR(30) NOT NULL UNIQUE,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE students (
 id INT AUTO_INCREMENT PRIMARY KEY,
 admission_number VARCHAR(50) NOT NULL UNIQUE,
 full_name VARCHAR(150) NOT NULL,
 gender ENUM('Male','Female') NOT NULL,
 date_of_birth DATE NULL,
 class_id INT NULL,
 admission_date DATE NULL,
 parent_name VARCHAR(150),
 parent_phone VARCHAR(30),
 address VARCHAR(255),
 status ENUM('Active','Inactive','Graduated') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_student_name(full_name),
 CONSTRAINT fk_student_class FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE examinations (
 id INT AUTO_INCREMENT PRIMARY KEY,
 exam_name VARCHAR(100) NOT NULL,
 term VARCHAR(30) NOT NULL,
 academic_year YEAR NOT NULL,
 start_date DATE NULL,
 end_date DATE NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE fees (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 payment_date DATE NOT NULL,
 payment_method VARCHAR(40) NOT NULL,
 reference_number VARCHAR(100),
 description VARCHAR(255),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_fee_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE attendance (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 attendance_date DATE NOT NULL,
 status ENUM('Present','Absent','Late','Excused') NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY unique_student_day(student_id,attendance_date),
 CONSTRAINT fk_attendance_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE results (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 subject_id INT NOT NULL,
 exam_id INT NOT NULL,
 marks DECIMAL(5,2) NOT NULL,
 grade VARCHAR(5),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY unique_result(student_id,subject_id,exam_id),
 CONSTRAINT fk_result_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
 CONSTRAINT fk_result_subject FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
 CONSTRAINT fk_result_exam FOREIGN KEY(exam_id) REFERENCES examinations(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE timetable (
 id INT AUTO_INCREMENT PRIMARY KEY,
 class_id INT NOT NULL,
 subject_id INT NOT NULL,
 teacher_id INT NULL,
 day_of_week VARCHAR(20),
 start_time TIME,
 end_time TIME,
 CONSTRAINT fk_time_class FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
 CONSTRAINT fk_time_subject FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
 CONSTRAINT fk_time_teacher FOREIGN KEY(teacher_id) REFERENCES teachers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Run install.php after importing this database to create the default admin account.

INSERT INTO subjects(subject_name,subject_code) VALUES
('English','ENG'),('Kiswahili','KIS'),('Mathematics','MAT'),
('Biology','BIO'),('Chemistry','CHE'),('Physics','PHY'),
('History','HIS'),('Geography','GEO'),('Christian Religious Education','CRE'),
('Business Studies','BUS'),('Computer Studies','COM'),('Agriculture','AGR');
INSERT INTO classes(class_name,stream) VALUES
('Form 1','East'),('Form 1','West'),('Form 2','East'),('Form 2','West'),
('Form 3','East'),('Form 3','West'),('Form 4','East'),('Form 4','West');
