<?php require __DIR__ . '/includes/crud_page.php'; ?>
