<?php
require_once __DIR__.'/config/app.php'; require_login();
$pageTitle='Settings';$activePage='settings';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();$current=$_POST['current_password']??'';$new=$_POST['new_password']??'';$confirm=$_POST['confirm_password']??'';
 $st=$pdo->prepare("SELECT password FROM users WHERE id=?");$st->execute([$_SESSION['user_id']]);$hash=$st->fetchColumn();
 if(!password_verify($current,$hash))$error='Current password is incorrect.';
 elseif(strlen($new)<8)$error='New password must contain at least 8 characters.';
 elseif($new!==$confirm)$error='New password and confirmation do not match.';
 else{$up=$pdo->prepare("UPDATE users SET password=? WHERE id=?");$up->execute([password_hash($new,PASSWORD_DEFAULT),$_SESSION['user_id']]);flash('success','Your password has been changed.');redirect('settings.php');}
}
require 'includes/header.php'; ?>
<div class="page-toolbar"><div><h2>Account settings</h2><p>Manage your administrator account.</p></div></div>
<div class="panel narrow-panel"><div class="panel-head"><div><h3>Change password</h3><p>Choose a strong password you have not used elsewhere.</p></div></div>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post" class="data-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><div class="form-grid single">
<div class="field"><label>Current password</label><input type="password" name="current_password" required></div>
<div class="field"><label>New password</label><input type="password" name="new_password" minlength="8" required></div>
<div class="field"><label>Confirm new password</label><input type="password" name="confirm_password" minlength="8" required></div>
</div><div class="form-actions"><button class="btn primary">Update password</button></div></form></div>
<div class="panel"><h3>School information</h3><p class="muted">Al-Fatah Secondary School · School Management System · Currency: Kenyan Shillings (KES)</p></div>
<?php require 'includes/footer.php'; ?>
