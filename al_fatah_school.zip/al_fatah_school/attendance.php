<?php
require_once __DIR__.'/config/app.php'; require_login();
$pageTitle='Attendance'; $activePage='attendance';
$students=$pdo->query("SELECT s.id,s.admission_number,s.full_name, c.class_name,c.stream FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.status='Active' ORDER BY s.full_name")->fetchAll();
$date=$_GET['date']??date('Y-m-d'); $message='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $date=$_POST['attendance_date']??date('Y-m-d'); $statuses=$_POST['status']??[];
 try{
  $pdo->beginTransaction();
  $stmt=$pdo->prepare("INSERT INTO attendance(student_id,attendance_date,status) VALUES(?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status)");
  foreach($statuses as $sid=>$status){ if(in_array($status,['Present','Absent','Late','Excused'],true)) $stmt->execute([(int)$sid,$date,$status]); }
  $pdo->commit(); flash('success','Attendance saved for '.count($statuses).' student(s).'); redirect('attendance.php?date='.urlencode($date));
 }catch(Throwable $e){$pdo->rollBack();$message=$e->getMessage();}
}
$existing=$pdo->prepare("SELECT student_id,status FROM attendance WHERE attendance_date=?");$existing->execute([$date]);$marked=$existing->fetchAll(PDO::FETCH_KEY_PAIR);
require 'includes/header.php';
?>
<div class="page-toolbar"><div><h2>Daily attendance</h2><p>Mark and update attendance for each student.</p></div><span class="pill"><?= count($students) ?> active students</span></div>
<?php if($message): ?><div class="alert error"><?= e($message) ?></div><?php endif; ?>
<div class="panel"><form method="get" class="date-filter"><label>Attendance date</label><input type="date" name="date" value="<?= e($date) ?>"><button class="btn light">Load date</button></form>
<form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="attendance_date" value="<?= e($date) ?>">
<div class="table-wrap"><table><thead><tr><th>Admission No.</th><th>Student</th><th>Class</th><th>Attendance status</th></tr></thead><tbody>
<?php if(!$students): ?><tr><td colspan="4" class="empty">Register students before taking attendance.</td></tr><?php else: foreach($students as $s): $st=$marked[$s['id']]??'Present'; ?><tr><td><?= e($s['admission_number']) ?></td><td><?= e($s['full_name']) ?></td><td><?= e(($s['class_name']??'').' '.($s['stream']??'')) ?></td><td><select name="status[<?= (int)$s['id'] ?>]" class="status-select"><?php foreach(['Present','Absent','Late','Excused'] as $v): ?><option <?= $st===$v?'selected':'' ?>><?= e($v) ?></option><?php endforeach; ?></select></td></tr><?php endforeach; endif; ?>
</tbody></table></div><div class="form-actions"><button class="btn primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save attendance</button></div></form></div>
<?php require 'includes/footer.php'; ?>
