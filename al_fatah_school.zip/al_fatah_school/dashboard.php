<?php
require_once __DIR__ . '/config/app.php';
require_login();
$pageTitle='Dashboard'; $activePage='dashboard';
$stats = [
 ['Students',db_count($pdo,'students'),'fa-user-graduate','blue','students.php'],
 ['Teachers',db_count($pdo,'teachers'),'fa-chalkboard-user','green','teachers.php'],
 ['Classes',db_count($pdo,'classes'),'fa-school','orange','classes.php'],
 ['Subjects',db_count($pdo,'subjects'),'fa-book-open','purple','subjects.php'],
];
$recent = $pdo->query("SELECT s.admission_number,s.full_name,s.gender,s.status,c.class_name,c.stream FROM students s LEFT JOIN classes c ON c.id=s.class_id ORDER BY s.id DESC LIMIT 6")->fetchAll();
$feeTotal = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM fees")->fetchColumn();
$attendanceToday = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE attendance_date=CURDATE()")->fetchColumn();
require 'includes/header.php';
?>
<div class="welcome-banner"><div><span class="eyebrow">SCHOOL ADMINISTRATION</span><h2>Welcome back, <?= e(current_user()) ?>!</h2><p>Here is your school's current overview. Use the menu to manage daily activities.</p></div><div class="banner-icon"><i class="fa-solid fa-school"></i></div></div>
<div class="stats-grid">
<?php foreach($stats as $s): ?><a class="stat-card" href="<?= e($s[4]) ?>"><span class="stat-icon <?= e($s[3]) ?>"><i class="fa-solid <?= e($s[2]) ?>"></i></span><span><small><?= e($s[0]) ?></small><strong><?= number_format($s[1]) ?></strong><em>View records <i class="fa-solid fa-arrow-up-right-from-square"></i></em></span></a><?php endforeach; ?>
</div>
<div class="dashboard-grid">
 <div class="panel"><div class="panel-head"><div><h3>School snapshot</h3><p>Live totals from your database</p></div><span class="pill">Updated live</span></div>
  <div class="snapshot-row"><span><i class="fa-solid fa-money-bill-wave"></i> Recorded fee payments</span><b>KES <?= number_format($feeTotal,2) ?></b></div>
  <div class="snapshot-row"><span><i class="fa-solid fa-calendar-check"></i> Attendance entries today</span><b><?= number_format($attendanceToday) ?></b></div>
  <div class="snapshot-row"><span><i class="fa-solid fa-file-circle-check"></i> Examinations created</span><b><?= db_count($pdo,'examinations') ?></b></div>
 </div>
 <div class="panel"><div class="panel-head"><div><h3>Quick actions</h3><p>Common school tasks</p></div></div><div class="quick-grid">
  <a href="students.php?action=add"><i class="fa-solid fa-user-plus"></i><span>Register student</span></a><a href="teachers.php?action=add"><i class="fa-solid fa-person-chalkboard"></i><span>Add teacher</span></a><a href="attendance.php"><i class="fa-solid fa-calendar-check"></i><span>Mark attendance</span></a><a href="fees.php?action=add"><i class="fa-solid fa-receipt"></i><span>Record payment</span></a>
 </div></div>
</div>
<div class="panel"><div class="panel-head"><div><h3>Recently registered students</h3><p>Latest student records</p></div><a class="text-link" href="students.php">View all <i class="fa-solid fa-arrow-right"></i></a></div>
<div class="table-wrap"><table><thead><tr><th>Admission no.</th><th>Student name</th><th>Gender</th><th>Class / Stream</th><th>Status</th></tr></thead><tbody>
<?php if(!$recent): ?><tr><td colspan="5" class="empty">No students registered yet. <a href="students.php?action=add">Register the first student</a>.</td></tr><?php else: foreach($recent as $r): ?><tr><td><b><?= e($r['admission_number']) ?></b></td><td><?= e($r['full_name']) ?></td><td><?= e($r['gender']) ?></td><td><?= e(trim(($r['class_name']??'Unassigned').' '.($r['stream']??''))) ?></td><td><span class="status <?= strtolower(e($r['status'])) ?>"><?= e($r['status']) ?></span></td></tr><?php endforeach; endif; ?>
</tbody></table></div></div>
<?php require 'includes/footer.php'; ?>
