<?php
require_once __DIR__ . '/config/app.php';
if (is_logged_in()) redirect('dashboard.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT id, full_name, username, password, role, status FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && $user['status'] === 'active' && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['role'] = $user['role'];
        redirect('dashboard.php');
    }
    $error = 'Incorrect username or password, or this account is inactive.';
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sign in | Al-Fatah</title><link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"></head>
<body class="login-page">
<div class="login-card">
  <div class="login-logo"><i class="fa-solid fa-graduation-cap"></i></div>
  <h1>Al-Fatah Secondary School</h1><p class="muted">School Management System</p>
  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <label>Username</label><div class="input-icon"><i class="fa-regular fa-user"></i><input name="username" required autofocus placeholder="Enter username"></div>
    <label>Password</label><div class="input-icon"><i class="fa-solid fa-lock"></i><input type="password" name="password" required placeholder="Enter password"></div>
    <button class="btn primary full" type="submit">Sign in <i class="fa-solid fa-arrow-right"></i></button>
  </form>
  <div class="login-hint"><b>First login:</b> username <code>admin</code> · password <code>Admin@123</code><br>Change the password after signing in.</div>
</div></body></html>
