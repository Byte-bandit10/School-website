</section>
<footer class="footer">© <?= date('Y') ?> Al-Fatah Secondary School. All rights reserved.</footer>
</main>
</div>
<script src="assets/script.js"></script>
</body>
</html>
