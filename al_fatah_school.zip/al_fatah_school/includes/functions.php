<?php
declare(strict_types=1);

function e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}
function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}
function require_login(): void {
    if (!is_logged_in()) redirect('login.php');
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verify_csrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(419);
        exit('Your session form token expired. Go back, refresh the page and try again.');
    }
}
function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function get_flash(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}
function current_user(): string {
    return $_SESSION['full_name'] ?? 'Administrator';
}
function db_count(PDO $pdo, string $table): int {
    $allowed = ['students','teachers','classes','subjects','attendance','fees','examinations','results','users'];
    if (!in_array($table, $allowed, true)) return 0;
    return (int)$pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
}
