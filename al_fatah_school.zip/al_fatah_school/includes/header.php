<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$activePage = $activePage ?? '';
$flashMessage = get_flash();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | Al-Fatah Secondary School</title>
<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
<div class="layout">
<aside class="sidebar" id="sidebar">
  <a class="brand" href="dashboard.php">
    <span class="brand-mark"><i class="fa-solid fa-graduation-cap"></i></span>
    <span><b>AL-FATAH</b><small>SECONDARY SCHOOL</small></span>
  </a>
  <div class="nav-label">OVERVIEW</div>
  <a class="nav-link <?= $activePage==='dashboard'?'active':'' ?>" href="dashboard.php"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
  <div class="nav-label">SCHOOL MANAGEMENT</div>
  <a class="nav-link <?= $activePage==='students'?'active':'' ?>" href="students.php"><i class="fa-solid fa-user-graduate"></i> Students</a>
  <a class="nav-link <?= $activePage==='teachers'?'active':'' ?>" href="teachers.php"><i class="fa-solid fa-chalkboard-user"></i> Teachers</a>
  <a class="nav-link <?= $activePage==='classes'?'active':'' ?>" href="classes.php"><i class="fa-solid fa-school"></i> Classes & Streams</a>
  <a class="nav-link <?= $activePage==='subjects'?'active':'' ?>" href="subjects.php"><i class="fa-solid fa-book"></i> Subjects</a>
  <div class="nav-label">ACADEMICS</div>
  <a class="nav-link <?= $activePage==='attendance'?'active':'' ?>" href="attendance.php"><i class="fa-solid fa-calendar-check"></i> Attendance</a>
  <a class="nav-link <?= $activePage==='examinations'?'active':'' ?>" href="examinations.php"><i class="fa-solid fa-file-lines"></i> Examinations</a>
  <a class="nav-link <?= $activePage==='results'?'active':'' ?>" href="results.php"><i class="fa-solid fa-chart-column"></i> Results</a>
  <div class="nav-label">FINANCE & ADMIN</div>
  <a class="nav-link <?= $activePage==='fees'?'active':'' ?>" href="fees.php"><i class="fa-solid fa-money-bill-wave"></i> Fees & Payments</a>
  <a class="nav-link <?= $activePage==='reports'?'active':'' ?>" href="reports.php"><i class="fa-solid fa-chart-pie"></i> Reports</a>
  <a class="nav-link <?= $activePage==='settings'?'active':'' ?>" href="settings.php"><i class="fa-solid fa-gear"></i> Settings</a>
  <div class="sidebar-bottom">
    <div class="user-chip"><span class="avatar"><?= e(strtoupper(substr(current_user(),0,1))) ?></span><span><b><?= e(current_user()) ?></b><small>Administrator</small></span></div>
    <a class="logout-link" href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Sign out</a>
  </div>
</aside>
<main class="main">
<header class="topbar">
  <button class="icon-btn mobile-menu" id="menuToggle" aria-label="Open menu"><i class="fa-solid fa-bars"></i></button>
  <div><h1><?= e($pageTitle) ?></h1><p>Al-Fatah Secondary School Management System</p></div>
  <div class="topbar-right"><span class="today"><?= date('D, d M Y') ?></span><span class="top-avatar"><?= e(strtoupper(substr(current_user(),0,1))) ?></span></div>
</header>
<section class="content">
<?php if ($flashMessage): ?>
<div class="alert <?= e($flashMessage['type']) ?>"><?= e($flashMessage['message']) ?></div>
<?php endif; ?>
