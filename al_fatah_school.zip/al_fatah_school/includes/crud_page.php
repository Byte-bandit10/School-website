<?php
require_once __DIR__ . '/../config/app.php';
require_login();

$configs = [
'students' => ['title'=>'Students','table'=>'students','key'=>'id','fields'=>[
 'admission_number'=>['Admission number','text',true],'full_name'=>['Full name','text',true],'gender'=>['Gender','select',true,['Male','Female']],
 'date_of_birth'=>['Date of birth','date',false],'class_id'=>['Class / stream','class',false],
 'admission_date'=>['Admission date','date',false],'parent_name'=>['Parent / guardian','text',false],
 'parent_phone'=>['Parent phone','text',false],'address'=>['Address','text',false],
 'status'=>['Status','select',true,['Active','Inactive','Graduated']]
], 'columns'=>['admission_number'=>'Admission No.','full_name'=>'Student','gender'=>'Gender','class_label'=>'Class','parent_phone'=>'Parent phone','status'=>'Status']],
'teachers' => ['title'=>'Teachers','table'=>'teachers','key'=>'id','fields'=>[
 'teacher_number'=>['Teacher number','text',false],'full_name'=>['Full name','text',true],'gender'=>['Gender','select',true,['Male','Female']],
 'phone'=>['Phone','text',false],'email'=>['Email','email',false],'qualification'=>['Qualification','text',false],'employment_date'=>['Employment date','date',false]
], 'columns'=>['teacher_number'=>'Staff No.','full_name'=>'Teacher','gender'=>'Gender','phone'=>'Phone','qualification'=>'Qualification']],
'classes' => ['title'=>'Classes & Streams','table'=>'classes','key'=>'id','fields'=>[
 'class_name'=>['Class name','select',true,['Form 1','Form 2','Form 3','Form 4']],'stream'=>['Stream','text',true],'class_teacher_id'=>['Class teacher','teacher',false]
], 'columns'=>['class_name'=>'Class','stream'=>'Stream','teacher_name'=>'Class teacher']],
'subjects' => ['title'=>'Subjects','table'=>'subjects','key'=>'id','fields'=>[
 'subject_name'=>['Subject name','text',true],'subject_code'=>['Subject code','text',true]
], 'columns'=>['subject_code'=>'Code','subject_name'=>'Subject']],
'fees' => ['title'=>'Fees & Payments','table'=>'fees','key'=>'id','fields'=>[
 'student_id'=>['Student','student',true],'amount'=>['Amount (KES)','number',true],'payment_date'=>['Payment date','date',true],
 'payment_method'=>['Payment method','select',true,['Cash','M-Pesa','Bank','Cheque','Other']],
 'reference_number'=>['Receipt / reference number','text',false],'description'=>['Description','text',false]
], 'columns'=>['payment_date'=>'Date','admission_number'=>'Admission No.','student_name'=>'Student','amount'=>'Amount (KES)','payment_method'=>'Method','reference_number'=>'Reference']],
'examinations' => ['title'=>'Examinations','table'=>'examinations','key'=>'id','fields'=>[
 'exam_name'=>['Examination name','text',true],'term'=>['Term','select',true,['Term 1','Term 2','Term 3']],
 'academic_year'=>['Academic year','number',true],'start_date'=>['Start date','date',false],'end_date'=>['End date','date',false]
], 'columns'=>['exam_name'=>'Examination','term'=>'Term','academic_year'=>'Year','start_date'=>'Start date','end_date'=>'End date']],
'results' => ['title'=>'Student Results','table'=>'results','key'=>'id','fields'=>[
 'student_id'=>['Student','student',true],'subject_id'=>['Subject','subject',true],'exam_id'=>['Examination','exam',true],
 'marks'=>['Marks (0–100)','number',true],'grade'=>['Grade','text',false]
], 'columns'=>['student_name'=>'Student','subject_name'=>'Subject','exam_name'=>'Examination','marks'=>'Marks','grade'=>'Grade']],
];
$module = basename($_SERVER['SCRIPT_NAME'], '.php');
if (!isset($configs[$module])) { http_response_code(404); exit('Module not found'); }
$c = $configs[$module]; $pageTitle=$c['title']; $activePage=$module;
$action = $_GET['action'] ?? 'list'; $id = (int)($_GET['id'] ?? 0);
function option_rows(PDO $pdo, string $type): array {
    return match($type) {
      'class' => $pdo->query("SELECT id, CONCAT(class_name,' ',stream) label FROM classes ORDER BY class_name,stream")->fetchAll(),
      'teacher' => $pdo->query("SELECT id,full_name label FROM teachers ORDER BY full_name")->fetchAll(),
      'student' => $pdo->query("SELECT id,CONCAT(admission_number,' - ',full_name) label FROM students ORDER BY full_name")->fetchAll(),
      'subject' => $pdo->query("SELECT id,CONCAT(subject_code,' - ',subject_name) label FROM subjects ORDER BY subject_name")->fetchAll(),
      'exam' => $pdo->query("SELECT id,CONCAT(exam_name,' (',term,' ',academic_year,')') label FROM examinations ORDER BY id DESC")->fetchAll(),
      default => []
    };
}
function form_value(string $field, array $record): string { return (string)($record[$field] ?? ''); }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $postAction = $_POST['form_action'] ?? '';
    try {
      if ($postAction==='delete') {
        $del=$pdo->prepare("DELETE FROM `{$c['table']}` WHERE id=?"); $del->execute([(int)($_POST['id']??0)]);
        flash('success', $c['title'].' record deleted.'); redirect($module.'.php');
      }
      $data=[];
      foreach($c['fields'] as $field=>$meta) {
        $v=trim((string)($_POST[$field]??''));
        if ($v==='' && !$meta[2]) $data[$field]=null;
        else {
          if ($meta[2] && $v==='') throw new RuntimeException($meta[0].' is required.');
          if ($meta[1]==='number' && $v!=='' && !is_numeric($v)) throw new RuntimeException($meta[0].' must be a number.');
          if ($field==='marks' && ($v<0 || $v>100)) throw new RuntimeException('Marks must be between 0 and 100.');
          $data[$field]=$v;
        }
      }
      if ($module==='students' && empty($data['admission_date'])) $data['admission_date']=date('Y-m-d');
      if ($module==='fees' && (float)$data['amount']<=0) throw new RuntimeException('Payment amount must be greater than zero.');
      if ($module==='results' && $data['grade']===null) {
        $m=(float)$data['marks']; $data['grade']=$m>=80?'A':($m>=70?'B':($m>=60?'C':($m>=50?'D':'E')));
      }
      if ($postAction==='update') {
        $sets=implode(',',array_map(fn($f)=>"`$f`=?",array_keys($data)));
        $stmt=$pdo->prepare("UPDATE `{$c['table']}` SET $sets WHERE id=?");
        $stmt->execute([...array_values($data),(int)($_POST['id']??0)]);
        flash('success',$c['title'].' record updated successfully.');
      } else {
        $cols=array_keys($data); $sqlCols=implode(',',array_map(fn($f)=>"`$f`",$cols)); $marks=implode(',',array_fill(0,count($cols),'?'));
        $stmt=$pdo->prepare("INSERT INTO `{$c['table']}` ($sqlCols) VALUES ($marks)"); $stmt->execute(array_values($data));
        flash('success',$c['title'].' record added successfully.');
      }
      redirect($module.'.php');
    } catch(Throwable $ex) { $error=$ex->getMessage(); $action=isset($_POST['id']) && $_POST['id']!==''?'edit':'add'; $id=(int)($_POST['id']??0); }
}
$record=[];
if ($action==='edit' && $id) { $st=$pdo->prepare("SELECT * FROM `{$c['table']}` WHERE id=?"); $st->execute([$id]); $record=$st->fetch() ?: []; if(!$record){flash('error','Record not found.');redirect($module.'.php');} }
$search=trim($_GET['q']??'');
if ($module==='students') $sql="SELECT s.*, CONCAT(COALESCE(c.class_name,''),' ',COALESCE(c.stream,'')) class_label FROM students s LEFT JOIN classes c ON c.id=s.class_id";
elseif($module==='teachers') $sql="SELECT * FROM teachers";
elseif($module==='classes') $sql="SELECT c.*,t.full_name teacher_name FROM classes c LEFT JOIN teachers t ON t.id=c.class_teacher_id";
elseif($module==='subjects') $sql="SELECT * FROM subjects";
elseif($module==='fees') $sql="SELECT f.*,s.full_name student_name,s.admission_number FROM fees f JOIN students s ON s.id=f.student_id";
elseif($module==='examinations') $sql="SELECT * FROM examinations";
else $sql="SELECT r.*,s.full_name student_name,sub.subject_name,ex.exam_name FROM results r JOIN students s ON s.id=r.student_id JOIN subjects sub ON sub.id=r.subject_id JOIN examinations ex ON ex.id=r.exam_id";
if($search!=='') {
  $searchable = match($module) {
    'students'=>"s.full_name LIKE ? OR s.admission_number LIKE ?",
    'teachers'=>"full_name LIKE ? OR teacher_number LIKE ?",
    'classes'=>"class_name LIKE ? OR stream LIKE ?",
    'subjects'=>"subject_name LIKE ? OR subject_code LIKE ?",
    'fees'=>"s.full_name LIKE ? OR s.admission_number LIKE ? OR f.reference_number LIKE ?",
    'examinations'=>"exam_name LIKE ? OR term LIKE ?",
    default=>"s.full_name LIKE ? OR sub.subject_name LIKE ? OR ex.exam_name LIKE ?"
  };
  $sql.=" WHERE ".$searchable;
  $params=array_fill(0,substr_count($searchable,'?'),"%$search%");
  $stmt=$pdo->prepare($sql." ORDER BY 1 DESC"); $stmt->execute($params); $rows=$stmt->fetchAll();
} else $rows=$pdo->query($sql." ORDER BY 1 DESC")->fetchAll();
require __DIR__.'/header.php';
?>
<div class="page-toolbar"><div><h2><?= e($c['title']) ?></h2><p>Manage and maintain <?= strtolower(e($c['title'])) ?> records.</p></div><a class="btn primary" href="<?= e($module) ?>.php?action=add"><i class="fa-solid fa-plus"></i> Add new</a></div>
<?php if(!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<?php if($action==='add'||$action==='edit'): ?>
<div class="panel form-panel"><div class="panel-head"><div><h3><?= $action==='edit'?'Edit record':'Add new record' ?></h3><p>Complete the information below.</p></div><a class="btn light" href="<?= e($module) ?>.php">Back to list</a></div>
<form method="post" class="data-form">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="form_action" value="<?= $action==='edit'?'update':'insert' ?>"><input type="hidden" name="id" value="<?= (int)$id ?>">
<div class="form-grid">
<?php foreach($c['fields'] as $field=>$meta): $value=form_value($field,$record); ?>
<div class="field"><label for="<?= e($field) ?>"><?= e($meta[0]) ?> <?= $meta[2]?'<span>*</span>':'' ?></label>
<?php if($meta[1]==='select'): ?><select id="<?= e($field) ?>" name="<?= e($field) ?>" <?= $meta[2]?'required':'' ?>><option value="">Choose...</option><?php foreach($meta[3] as $opt): ?><option <?= $value===$opt?'selected':'' ?> value="<?= e($opt) ?>"><?= e($opt) ?></option><?php endforeach; ?></select>
<?php elseif(in_array($meta[1],['class','teacher','student','subject','exam'],true)): ?><select id="<?= e($field) ?>" name="<?= e($field) ?>" <?= $meta[2]?'required':'' ?>><option value="">Choose...</option><?php foreach(option_rows($pdo,$meta[1]) as $opt): ?><option value="<?= (int)$opt['id'] ?>" <?= (string)$value===(string)$opt['id']?'selected':'' ?>><?= e($opt['label']) ?></option><?php endforeach; ?></select>
<?php else: ?><input id="<?= e($field) ?>" name="<?= e($field) ?>" type="<?= e($meta[1]) ?>" value="<?= e($value) ?>" <?= $meta[2]?'required':'' ?> <?= $meta[1]==='number'?'step="0.01"':'' ?>><?php endif; ?>
</div>
<?php endforeach; ?>
</div><div class="form-actions"><button class="btn primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save record</button><a class="btn light" href="<?= e($module) ?>.php">Cancel</a></div></form></div>
<?php else: ?>
<div class="panel"><div class="list-toolbar"><form method="get" class="search-form"><i class="fa-solid fa-magnifying-glass"></i><input name="q" value="<?= e($search) ?>" placeholder="Search records..."><button class="btn light" type="submit">Search</button><?php if($search!==''): ?><a class="btn light" href="<?= e($module) ?>.php">Clear</a><?php endif; ?></form><span class="record-count"><?= count($rows) ?> record(s)</span></div>
<div class="table-wrap"><table><thead><tr><?php foreach($c['columns'] as $label): ?><th><?= e($label) ?></th><?php endforeach; ?><th>Actions</th></tr></thead><tbody>
<?php if(!$rows): ?><tr><td colspan="<?= count($c['columns'])+1 ?>" class="empty">No records found. Use “Add new” to create your first record.</td></tr><?php else: foreach($rows as $row): ?><tr>
<?php foreach($c['columns'] as $field=>$label): ?><td><?php if($field==='status'): ?><span class="status <?= strtolower(e($row[$field]??'')) ?>"><?= e($row[$field]??'') ?></span><?php elseif($field==='amount'): ?><b>KES <?= number_format((float)$row[$field],2) ?></b><?php else: ?><?= e($row[$field]??'—') ?><?php endif; ?></td><?php endforeach; ?>
<td><div class="actions"><a class="action edit" title="Edit" href="<?= e($module) ?>.php?action=edit&id=<?= (int)$row['id'] ?>"><i class="fa-solid fa-pen"></i></a><form method="post" onsubmit="return confirm('Delete this record? This cannot be undone.');"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" value="<?= (int)$row['id'] ?>"><button class="action delete" title="Delete"><i class="fa-solid fa-trash"></i></button></form></div></td></tr><?php endforeach; endif; ?>
</tbody></table></div></div>
<?php endif; ?>
<?php require __DIR__.'/footer.php'; ?>
